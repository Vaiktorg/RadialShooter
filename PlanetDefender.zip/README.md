Radial Shooter
==============

This is a GBAJam5 Itch.io submission.


----------


###Work Dimmension:

 - 160px x 144px
 
Every sprite, map, etc will be done by these dimmensions.
NO ANTIALIASING! 

###Window Dimmension:

- 640px x 576px

We can achieve this by using a Camera2D node with a zoom scale of 4 and setting the windows display dimmensions to 640px x 576px.

